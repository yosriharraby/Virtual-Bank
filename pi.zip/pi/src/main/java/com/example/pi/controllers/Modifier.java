package com.example.pi.controllers;

import com.example.pi.models.cheque;
import com.example.pi.services.chequeservice;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

import java.sql.SQLException;

public class Modifier {


    @FXML
    private TextField beneficiareTF1;

    @FXML
    private TextField date_emissionTF;

    @FXML
    private TextField emetteurTF1;

    @FXML
    private AnchorPane modificationcheque;

    @FXML
    private TextField montantTF1;

    private  cheque c ;
    private final chequeservice cs = new chequeservice();

    public void setC(cheque c) {
        this.c = c;
    }

    public static void showAlert(Alert.AlertType type, String title, String content) {
        Alert alert = new Alert(type);
        alert.setTitle(title);

        alert.setContentText(content);
        alert.showAndWait();
    }

    public boolean controlSaisie (TextField field){
        if (field.getText().isEmpty() ) {
            showAlert(Alert.AlertType.ERROR, "champ vide", "remplir le champ vides");
            return false;
        }
        return true;
    }

    public void initData(cheque ch) {
        if (ch != null) {
            date_emissionTF.setText(String.valueOf(ch.getDate_emission()));
            emetteurTF1.setText(ch.getEmetteur());
            beneficiareTF1.setText(String.valueOf(ch.getBeneficiaire()));
            montantTF1.setText(String.valueOf(ch.getMontant()));
        }}


    @FXML
    void ok(ActionEvent event) throws SQLException {
        float montant = Float.parseFloat(montantTF1.getText());
        if(controlSaisie(date_emissionTF)&&controlSaisie(emetteurTF1)&&controlSaisie(montantTF1)){
            cheque ch = new cheque(0,montant,beneficiareTF1.getText(),emetteurTF1.getText(),"Statut initial",date_emissionTF.getText());
            cs.modifier(ch);
            showAlert(Alert.AlertType.INFORMATION,"Succée","cheque est modifée");
            Stage stage = (Stage) modificationcheque.getScene().getWindow();
            stage.close();

        }

    }}
package com.example.pi.test;

import com.example.pi.models.cheque;
import com.example.pi.services.chequeservice;

import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class main2 {
    public static void main(String[] args) throws ParseException, SQLException {
        chequeservice cs = new chequeservice();

        SimpleDateFormat formatter = new SimpleDateFormat("dd-MMM-yyyy", Locale.ENGLISH);
        String dateInString = "7-Jun-2023";
        Date date = formatter.parse(dateInString);

        // Utilisez java.sql.Date pour représenter la date dans le format MySQL
        java.sql.Date sqlDate = (date != null) ? new java.sql.Date(date.getTime()) : null;

        // Ajouter un chèque
      // cs.ajouter(new cheque(123, 500.0f, "John Doe", "Company XYZ", "En attente", sqlDate));
       cs.ajouter(new cheque(127, 1345.500f, "JUlIEN", "Company Aramex", "encaissé", "12"));
        // Modifier un chèque (remarque : cette opération nécessitera probablement une méthode spécifique pour modifier)
         //cs.modifier(new cheque(127, 1500.14f, "JULIEN", "meublatex", "En attente", sqlDate));
        // Supprimer un chèque
        //cs.supprimer("127");

        // Récupérer la liste des chèques
     //  List<cheque> recuperer = cs.recuperer();
      //  for (cheque c : recuperer) {
           // System.out.println(c.toString());
        //}
   }
}


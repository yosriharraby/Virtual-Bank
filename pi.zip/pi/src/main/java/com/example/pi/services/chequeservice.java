package com.example.pi.services;

import com.example.pi.models.cheque;

import com.example.pi.utils.database;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;


public class chequeservice implements Iservice1<cheque> {
        private Connection connection;

        public chequeservice() {
            connection = database.getInstance().getConnection();
        }

    @Override
    public void ajouter(cheque cheque) throws SQLException {
        String req = "INSERT INTO cheque (numero_de_cheque, montant, beneficiaire, emetteur, statut, date_emission) " +
                "VALUES (?, ?, ?, ?, ?, ?)";

        try (PreparedStatement statement = connection.prepareStatement(req)) {
            statement.setInt(1, cheque.getNumero_de_cheque());
            statement.setFloat(2, cheque.getMontant());
            statement.setString(3, cheque.getBeneficiaire());
            statement.setString(4, cheque.getEmetteur());
            statement.setString(5, cheque.getStatut());

            // Vérifier si la date d'émission est non nulle avant de l'ajouter à la requête
            if (cheque.getDate_emission() != null) {
                statement.setObject(6, cheque.getDate_emission());
            }

            statement.executeUpdate();
            System.out.println("Ajout réussi : " + cheque.toString());
        } catch (SQLException e) {
            System.err.println("Erreur lors de l'ajout : " + e.getMessage());
        }
    }


    @Override
    public void modifier(cheque cheque) throws SQLException {
        String req = "UPDATE cheque SET " +
                "montant = ?, " +
                "beneficiaire = ?, " +
                "emetteur = ?, " +
                "statut = ?, " +
                "date_emission = ? " +
                "WHERE numero_de_cheque = ?";

        try (PreparedStatement statement = connection.prepareStatement(req)) {
            // Paramètres pour la mise à jour
            statement.setFloat(1, cheque.getMontant());
            statement.setString(2, cheque.getBeneficiaire());
            statement.setString(3, cheque.getEmetteur());
            statement.setString(4, cheque.getStatut());
            statement.setString(5,cheque.getDate_emission() );

            // Paramètre pour la clause WHERE
            statement.setInt(6, cheque.getNumero_de_cheque());

            // Exécution de la requête de mise à jour
            int rowsUpdated = statement.executeUpdate();

            if (rowsUpdated > 0) {
                System.out.println("Mise à jour réussie pour le numéro de chèque : " + cheque.getNumero_de_cheque());
            } else {
                System.out.println("Aucune ligne mise à jour. Vérifiez le numéro de chèque : " + cheque.getNumero_de_cheque());
            }
        } catch (SQLException e) {
            System.err.println("Erreur lors de la mise à jour : " + e.getMessage());
        }
    }

    @Override
    public void supprimer(int numero_de_cheque) throws SQLException {
        final String DELETE_CHEQUE = "DELETE FROM cheque WHERE numero_de_cheque = ?";

        try (PreparedStatement statement = connection.prepareStatement(DELETE_CHEQUE)) {
            statement.setInt(1, numero_de_cheque);

            // Exécution de la requête de suppression
            int rowsDeleted = statement.executeUpdate();

            if (rowsDeleted > 0) {
                System.out.println("Suppression réussie pour le numéro de chèque : " + numero_de_cheque);
            } else {
                System.out.println("Aucune ligne supprimée. Vérifiez le numéro de chèque : " + numero_de_cheque);
            }
        } catch (SQLException e) {
            System.err.println("Erreur lors de la suppression : " + e.getMessage());
        }
    }


    @Override
    public List<cheque> recuperer() {
        List<cheque> listeCheques = new ArrayList<>();

        final String SELECT_ALL_CHEQUES = "SELECT * FROM cheque";

        try (PreparedStatement statement = connection.prepareStatement(SELECT_ALL_CHEQUES)) {
            ResultSet resultSet = statement.executeQuery();

            while (resultSet.next()) {
                int numeroDeCheque = resultSet.getInt("numero_de_cheque");
                float montant = resultSet.getFloat("montant");
                String beneficiaire = resultSet.getString("beneficiaire");
                String emetteur = resultSet.getString("emetteur");
                String statut = resultSet.getString("statut");
                String dateEmission = resultSet.getString("date_emission");

                // Créez un objet cheque avec les données récupérées
                cheque c = new cheque(numeroDeCheque, montant, beneficiaire, emetteur, statut, dateEmission);

                // Ajoutez le cheque à la liste
                listeCheques.add(c);
            }
        } catch (SQLException e) {
            System.err.println("Erreur lors de la récupération des chèques : " + e.getMessage());
        }

        return listeCheques;
    }
}

package com.example.pi.controllers;

import com.example.pi.models.SwitchScene;
import com.example.pi.models.demandecheque;
import com.example.pi.services.demandechequeservice;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;

import java.io.IOException;
import java.sql.SQLException;

public class Ajouterdemande {
    @FXML
    private TextField cinTF;
    @FXML
    private TextField date_demandeTF;

    @FXML
    private TextField montant_demandéTF;

    @FXML
    private TextField num_telephoneTF;

    @FXML
    private TextArea raisonTF;

    @FXML
    private TextField typechequeTF;
    @FXML
    private AnchorPane ajouterPage1;


    private final demandechequeservice dc = new demandechequeservice();



    @FXML
    void ajouterDemande(ActionEvent event) throws SQLException, IOException {
        if (montant_demandéTF.getText().isEmpty() || num_telephoneTF.getText().isEmpty() || raisonTF.getText().isEmpty() || typechequeTF.getText().isEmpty()||date_demandeTF.getText().isEmpty()) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Erreur");
            alert.setHeaderText("Erreur de saisie !");
            alert.setContentText("Veuillez remplir tous les champs, y compris la date.");
            alert.show();
        } else {
            // Conversion de la chaîne montantTF en float
            float montant1 = Float.parseFloat(montant_demandéTF.getText());

            // Conversion de la chaîne de texte de la date en java.sql.Date

            dc.ajouter(new demandecheque("08794561", raisonTF.getText(), "barre", num_telephoneTF.getText(), cinTF.getText() ,date_demandeTF.getText(), montant1));

        }
    }

    public void afficherdemande(ActionEvent actionEvent) throws IOException {
        SwitchScene ss = new SwitchScene(ajouterPage1,"/com/example/pi/afficherdemandes.fxml");
    }
}
package com.example.pi.models;
import java.util.Date;


public class cheque {
   private int numero_de_cheque;
   private float montant;


   private String beneficiaire,emetteur,statut,date_emission;




   public cheque(int numero_de_cheque, float montant, String beneficiaire, String emetteur, String statut, String date_emission) {
      this.numero_de_cheque = numero_de_cheque;
      this.montant = montant;
      this.beneficiaire = beneficiaire;
      this.emetteur = emetteur;
      this.statut = statut;
      this.date_emission = date_emission;
   }



   public int getNumero_de_cheque() {
      return numero_de_cheque;
   }

   public float getMontant() {
      return montant;
   }

   public String getBeneficiaire() {
      return beneficiaire;
   }

   public String getEmetteur() {
      return emetteur;
   }

   public String getStatut() {
      return statut;
   }

   public String getDate_emission() {
      return date_emission;
   }

   @Override
   public String toString() {
      return "cheque{" +
              "numero_de_cheque=" + numero_de_cheque +
              ", montant=" + montant +
              ", beneficiaire='" + beneficiaire + '\'' +
              ", emetteur='" + emetteur + '\'' +
              ", statut='" + statut + '\'' +
              ", date_emission=" + date_emission +
              '}';
   }
}


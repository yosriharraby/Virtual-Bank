package com.example.pi.controllers;

import com.example.pi.models.cheque;
import com.example.pi.models.demandecheque;
import com.example.pi.services.chequeservice;
import com.example.pi.services.demandechequeservice;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.ListView;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.util.List;
import java.util.ResourceBundle;

public class Afficherdemandes implements Initializable {

    @FXML
    private ListView<demandecheque> listview;
    private final demandechequeservice dc = new demandechequeservice();
    List<demandecheque> alldemands = dc.recuperer();
    public void supprimerdemande(ActionEvent actionEvent) throws SQLException {
        demandecheque demandecheque = listview.getSelectionModel().getSelectedItem();
        if (demandecheque != null){
            dc.supprimer(demandecheque.getNuméro_compte());
            listview.getItems().remove(demandecheque);
            Alert alert = new Alert(Alert.AlertType.INFORMATION);

            alert.setTitle("demande Cheque est supprimee");
            alert.setContentText("demande Cheque est supprimer");
            alert.show();

        }else {
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Selecter un Cheque");
            alert.setContentText("selecter une Cheque");
            alert.show();
        }

    }

    public void modifierDemandes(ActionEvent actionEvent) throws IOException {
        demandecheque demandecheque = listview.getSelectionModel().getSelectedItem();
        if(demandecheque != null){
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/example/pi/modifierdemande.fxml"));
            Parent root = loader.load();
            Modifierdemande modifierCheque = loader.getController();
            modifierCheque.initData(demandecheque);
            modifierCheque.setC(demandecheque);
            Stage stage = new Stage();
            stage.setScene(new Scene(root));
            stage.show();
        }else {
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.setTitle("Error");
            alert.setContentText("You must select a Stock ! ");
            alert.show();
        }

    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        listview.getItems().addAll( alldemands);
    }
}

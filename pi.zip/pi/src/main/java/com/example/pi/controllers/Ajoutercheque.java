package com.example.pi.controllers;

import com.example.pi.models.QRCodeGenerator;
import com.example.pi.models.SwitchScene;
import com.example.pi.models.cheque;
import com.example.pi.services.chequeservice;

import com.google.zxing.*;
import com.google.zxing.common.HybridBinarizer;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.TextField;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import javafx.stage.FileChooser;
import javafx.stage.Stage;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.sql.SQLException;
import java.util.Base64;
import java.util.EnumMap;
import java.util.Map;

import com.google.zxing.Result;
import com.google.zxing.client.j2se.BufferedImageLuminanceSource;

public class Ajoutercheque {

    @FXML
    private TextField beneficiareTF;

    @FXML
    private TextField date_emissionTF;

    @FXML
    private TextField emetteurTF;

    @FXML
    private TextField montantTF;

    @FXML
    private ImageView qrcode;

    @FXML
    private AnchorPane ajouterPage;

    private final chequeservice cs = new chequeservice();
    private final String apiUrl = "http://localhost:8080/api/cheques";

    private String qrCodeData;
    private String content;
    private String username= "root";
private String password="root";
    @FXML
    void affichercheque(ActionEvent event) throws IOException {
        // Votre code pour afficher les chèques
        SwitchScene ss = new SwitchScene(ajouterPage, "/com/example/pi/afficherCheque.fxml");
    }

    @FXML
    void ajoutercheque(ActionEvent event) throws SQLException {
        if (beneficiareTF.getText().isEmpty() || emetteurTF.getText().isEmpty() || montantTF.getText().isEmpty() || date_emissionTF.getText().isEmpty()) {
            showAlert("Erreur", "Veuillez remplir tous les champs, y compris la date.");
        } else {
            float montant = Float.parseFloat(montantTF.getText());
            cs.ajouter(new cheque(12, montant, beneficiareTF.getText(), emetteurTF.getText(), "Statut initial", date_emissionTF.getText()));
        }
        String qrCodeText = beneficiareTF.getText() + "," + emetteurTF.getText() + "," + montantTF.getText() + "," + date_emissionTF.getText();
        QRCodeGenerator.generateQRCode(qrCodeText, 300, 300, "C:\\Users\\Lenovo\\IdeaProjects\\pi\\src\\main\\resources\\images\\qr.png");
    }

    public void afficherQRCode(ActionEvent actionEvent) {
        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("Choisir une image QR Code");
        File file = fileChooser.showOpenDialog(new Stage());

        if (file != null) {
            try {
                BufferedImage bufferedImage = ImageIO.read(file);
                String result = decodeQRCode(bufferedImage);
                updateFieldsWithQRCodeData(result);
            } catch (IOException e) {
                e.printStackTrace();
                showAlert("Erreur", "Erreur lors du chargement de l'image QR Code.");
            } catch (NotFoundException e) {
                showAlert("Erreur", "Aucun QR Code trouvé dans l'image.");
            }
        }
    }

    private void updateFieldsWithQRCodeData(String qrCodeData) {
        String[] qrCodeParts = qrCodeData.split(",");

        if (qrCodeParts.length >= 4) {
            beneficiareTF.setText(qrCodeParts[0].trim());
            emetteurTF.setText(qrCodeParts[1].trim());
            montantTF.setText(qrCodeParts[2].trim());
            date_emissionTF.setText(qrCodeParts[3].trim());
        } else {
            showAlert("Erreur", "Format QR Code non valide.");
        }
    }

    private String decodeQRCode(BufferedImage bufferedImage) throws NotFoundException {
        BinaryBitmap binaryBitmap = new BinaryBitmap(new HybridBinarizer(new BufferedImageLuminanceSource(bufferedImage)));
        Map<DecodeHintType, Object> hints = new EnumMap<>(DecodeHintType.class);
        hints.put(DecodeHintType.TRY_HARDER, Boolean.TRUE);

        Result result = new MultiFormatReader().decode(binaryBitmap, hints);
        return result.getText();
    }

    private void showAlert(String title, String content) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(content);
        alert.showAndWait();
    }

    public void getInformationsData(ActionEvent actionEvent) {
        try {

            System.out.println(apiUrl);
            URL url = new URL(apiUrl);
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            connection.setRequestMethod("GET");

            int responseCode = connection.getResponseCode();

            if (responseCode == HttpURLConnection.HTTP_OK) {
                // Autorisation réussie, traiter la réponse ici

                // Par exemple, lire la réponse du serveur
                BufferedReader reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
                String line;
                StringBuilder response = new StringBuilder();

                while ((line = reader.readLine()) != null) {
                    response.append(line);
                }

                reader.close();

                // Utilisez la réponse comme nécessaire
                System.out.println("Réponse du serveur : " + response.toString());
            } else {
                // Autorisation échouée, gérer en conséquence
                showAlert("Erreur d'autorisation", "L'accès au serveur a échoué avec le code : " + responseCode);
            }


            System.out.println("Code de réponse HTTP : " + responseCode);
            connection.disconnect();
        } catch (Exception e) {
            e.printStackTrace();
            showAlert("Erreur", "Erreur lors de la récupération des données de chèques : " + e.getMessage());
        }
    }
}

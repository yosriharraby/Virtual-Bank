package com.example.pi.models;

public class demandecheque {
    private String numéro_compte,raison,type_cheque,tel,date_demande;
    private int cin;

    private float montant_demandé;

    public demandecheque(String number, String text, String typeChequeTF1Text, String numTelephoneTF1Text, String cinTF1Text, String dateDemandeTFText, float montant2) {
    }

    public demandecheque(int cin, float montant_demandé, String tel, String raison, String type_cheque){}

    public demandecheque(String numéro_compte, String raison, String type_cheque, String tel, int cin, String date_demande, float montant_demandé) {
        this.numéro_compte = numéro_compte;
        this.raison = raison;
        this.type_cheque = type_cheque;
        this.tel = tel;
        this.cin = cin;
        this.date_demande = date_demande;
        this.montant_demandé = montant_demandé;
    }

    public String getNuméro_compte() {
        return numéro_compte;
    }

    public String getRaison() {
        return raison;
    }

    public String getDate_demande() {
        return date_demande;
    }



    public float getMontant_demandé() {
        return montant_demandé;
    }

    public void setNuméro_compte(String numéro_compte) {
        this.numéro_compte = numéro_compte;
    }

    public void setRaison(String raison) {
        this.raison = raison;
    }

    public void setDate_demande(String date_demande) {
        this.date_demande = date_demande;
    }


    public void setMontant_demandé(float montant_demandé) {
        this.montant_demandé = montant_demandé;
    }

    public String getType_cheque() {
        return type_cheque;
    }

    public void setType_cheque(String type_cheque) {
        this.type_cheque = type_cheque;
    }

    public String getTel() {
        return tel;
    }

    public void setTel(String tel) {
        this.tel = tel;
    }

    public int getCin() {
        return cin;
    }

    public void setCin(int cin) {
        this.cin = cin;
    }

    @Override
    public String toString() {
        return "demandecheque{" +
                "numéro_compte='" + numéro_compte + '\'' +
                ", raison='" + raison + '\'' +
                ", type_cheque='" + type_cheque + '\'' +
                ", tel='" + tel + '\'' +
                ", cin=" + cin +
                ", date_demande=" + date_demande +
                ", montant_demandé=" + montant_demandé +
                '}';
    }
}

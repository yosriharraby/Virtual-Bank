package com.example.pi.controllers;

import com.example.pi.models.cheque;
import com.example.pi.services.chequeservice;
import io.github.palexdev.materialfx.controls.MFXButton;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.ListView;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.util.List;
import java.util.ResourceBundle;

public class Affichercheque implements Initializable {

    @FXML
    private ListView<cheque> listview;
    private final chequeservice cs = new chequeservice();
    List<cheque> allCheque = cs.recuperer();


    @FXML
    void supprimerCheque(ActionEvent event) throws SQLException {
        cheque cheque = listview.getSelectionModel().getSelectedItem();
        if (cheque != null){
            cs.supprimer(cheque.getNumero_de_cheque());
            listview.getItems().remove(cheque);
            Alert alert = new Alert(Alert.AlertType.INFORMATION);

            alert.setTitle("Cheque est supprimee");
            alert.setContentText("Cheque est supprimer");
            alert.show();

        }else {
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Selecter un Cheque");
            alert.setContentText("selecter une Cheque");
            alert.show();
        }

    }
    @FXML
    void modifierCheque(ActionEvent event) throws IOException {
        cheque cheque = listview.getSelectionModel().getSelectedItem();
        if(cheque != null){
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/example/pi/modifier.fxml"));
            Parent root = loader.load();
            Modifier modifierCheque = loader.getController();
            modifierCheque.initData(cheque);
            modifierCheque.setC(cheque);
            Stage stage = new Stage();
            stage.setScene(new Scene(root));
            stage.show();
        }else {
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.setTitle("Error");
            alert.setContentText("You must select a Stock ! ");
            alert.show();
        }

    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        listview.getItems().addAll(allCheque);


    }
}